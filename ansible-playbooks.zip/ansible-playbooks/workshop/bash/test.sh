#!/bin/bash
dd if=/dev/zero of=/dev/null bs=512M count=3

