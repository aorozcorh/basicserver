#!/bin/bash
#subscription-manager repos --disable=*
#subscription-manager repos --enable=rhel-7-server-rpms
echo "Hola"
