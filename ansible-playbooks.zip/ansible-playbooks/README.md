Ansible examples by root_san
----------------------------
Simple repository to demostrate capabilities of ansible, the goal is just a example.
